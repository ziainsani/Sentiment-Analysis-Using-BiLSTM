from cgitb import text
import string
import nltk
nltk.download('stopwords')
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory, StopWordRemover, ArrayDictionary
from nltk.classify import maxent
from nltk.corpus import stopwords
import numpy as np
import pickle
import re
import time
import tensorflow as tf
from flask import Flask, request, jsonify, render_template
from tensorflow import keras
import requests
from keras.preprocessing.text import Tokenizer
from keras_preprocessing.sequence import pad_sequences
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from unidecode import unidecode
import pandas as pd


# def response():
#   response = requests.get(url)
#   response.raise_for_status()  # raises exception when not a 2xx response
#   if response.status_code != 204:
    
#     return response.json()

classifier = keras.models.load_model('modelbilstm')

STOPWORDS = set(stopwords.words('indonesian'))
stopwords = STOPWORDS

MAX_SEQUENCE_LENGTH = 64

tokenizer = Tokenizer(lower=True)
tokenizer.fit_on_texts("komentar")

word_index = tokenizer.word_index
vocab_size = len(tokenizer.word_index) + 1

komentar = pad_sequences(tokenizer.texts_to_sequences('komentar'),
                       maxlen = MAX_SEQUENCE_LENGTH)
factory = StemmerFactory()
stemmer = factory.create_stemmer()


def preproses(text):
    """ MENGHILANGKAN ANGKA """
    text = ''.join([i for i in text if not i.isdigit()])

    """ MENGHILANGKAN TANDA BACA LAINNYA"""
    text = text.translate(str.maketrans("  ", "  ", string.punctuation))

    text = re.sub(r'\s+', ' ', text).strip()

    """ RUBAH MENJADI HURUF KECIL """


    text = text.lower()

    substitute_word = ['[cm]', '[url]', '[sensitive-no']
    text = ' '.join('' if words in substitute_word else words for words in text.split(' '))

    """ MENGHILANGKAN KATA MEMANJANG """
    # text = re.compile(r"(.)\1{2}")

    text = stemmer.stem(text)

    return text

EMBEDDING_DIM = 300
LR = 1e-3
BATCH_SIZE = 500
EPOCHS = 10
embeddings_index = {}

# def bobot(text):
# f = open("glove.6b.300d.txt", "r", encoding='utf-8')
# for line in f:
#   values = line.split()
#   word = value = values[0]
#   coefs = np.asarray(values[1:], dtype='float32')
#   embeddings_index[word] = coefs
# f.close()
# embedding_matrix = np.zeros((vocab_size, EMBEDDING_DIM))
# for word, i in word_index.items():
#   embedding_vector = embeddings_index.get(word)
#   if embedding_vector is not None:
#     embedding_matrix[i] = embedding_vector
#     # return text



SENTIMENT_THRESHOLDS = (0.4, 0.7)
Positif = "Positif"
Negatif = "Negatif"
def decode_sentiment(score):
        if score <= SENTIMENT_THRESHOLDS[0]:
            label = Negatif
        elif score >= SENTIMENT_THRESHOLDS[1]:
            label = Positif

        return Negatif if score <= 0.7 else Positif

awal = time.time()
# df= pd.read_excel('kawahpth.xlsx')

app = Flask(__name__)
# instagram = Instagram()

@app.route('/')
def home():
    
  return render_template('index.html')

@app.route('/predict',methods=['POST'])
# @retry_on_rate_limiting
def predict():
    # awal = time.time()
    text = [str(x) for x in request.form.values()]
    # text = df
    # mdata = np.array(mdata)
    # start_at = time.time()
    # Tokenize text
    text = preproses(text)
    f = open("glove.6b.300d.txt", "r", encoding='utf-8')
    for line in f:
        values = line.split()
        word = value = values[0]
        coefs = np.asarray(values[1:], dtype='float32')
        embeddings_index[word] = coefs
    f.close()
    embedding_matrix = np.zeros((vocab_size, EMBEDDING_DIM))
    for word, i in word_index.items():
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    # text = bobot(text)
    komentar = pad_sequences(tokenizer.texts_to_sequences([text]), maxlen =MAX_SEQUENCE_LENGTH)
    # Predict
    score = classifier.predict([komentar])[0]
    # Decode sentiment
    label = decode_sentiment(score)
    # df["label"] = df["Text"].apply(lambda text: predict(text))
    return render_template("index.html", hasil = label)

if __name__ == "__main__":
  app.run(debug=True)
